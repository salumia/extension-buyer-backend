<?php

/**
 *	Client Helpers
 */
