<?php

Route::get('client', 'ClientController@welcome');
