<?php

return [
    'welcome' => 'Welcome, this is Product module.'
];
