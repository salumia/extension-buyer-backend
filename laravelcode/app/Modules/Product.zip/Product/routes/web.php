<?php

Route::get('product', 'ProductController@welcome');
