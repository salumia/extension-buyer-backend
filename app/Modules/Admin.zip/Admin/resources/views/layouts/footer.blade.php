
    <!-- Scripts -->
    <script src="{{ asset('admin/js/jquery.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery-ui.min.js') }}"></script>
    <script src="{{ asset('admin/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('admin/js/perfect-scrollbar.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery.sparkline.min.js') }}"></script>
    <script src="{{ asset('admin/js/raphael.min.js') }}"></script>
    <script src="{{ asset('admin/js/morris.min.js') }}"></script>
    <script src="{{ asset('admin/js/select2.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery-jvectormap.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery-jvectormap-world-mill.min.js') }}"></script>
    <script src="{{ asset('admin/js/horizontal-timeline.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('admin/js/jquery.steps.min.js') }}"></script>
    <script src="{{ asset('admin/js/dropzone.min.js') }}"></script>
    <script src="{{ asset('admin/js/ion.rangeSlider.min.js') }}"></script>
    <script src="{{ asset('admin/js/datatables.min.js') }}"></script>
    <script src="{{ asset('admin/js/main.js') }}"></script>
    <script src="{{ asset('admin/js/dashboard.js') }}"></script>
    <!-- Page Level Scripts -->

</body>
</html>
